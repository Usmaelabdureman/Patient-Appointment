import React from 'react'
import Contact from '../../components/contact/Contact'
import Footer from '../../components/footer/Footer'
import Header from '../../components/header/Header'
import Service from '../../components/services/Service'

function Landing() {
  return (
    <div>
      
      <Header />
      <Service />
      <Contact />
      <Footer />
    </div>
  )
}

export default Landing
